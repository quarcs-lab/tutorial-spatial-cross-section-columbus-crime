# tutorial-spatial-cross-section-columbus-crime
Tutorial : Spatial econometrics for cross-sectional data (Columbus crime example)
